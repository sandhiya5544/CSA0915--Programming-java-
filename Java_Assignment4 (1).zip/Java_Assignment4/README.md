# CSA09 - Assignment 4
## Event-Driven GUI Design Using Java

### Student Details
- Name: Reshma
- Register Number: 192421256
- Course: Programming in Java
- Course Code: CSA09
- Programming Language: Java
- Java Version: Java 17 or above

## Introduction
This assignment focuses on designing and implementing event-driven graphical user interfaces using Java AWT and Swing.

## Tasks Completed

### Task 1 – GUI Design Review
Designed a Student Fee Payment System using Java Swing.
Implemented separate service logic, payment validation, reset and receipt features.

### Task 2 – Requirement to Event-Driven Design
Developed a Hospital Appointment Booking System.
Implemented department selection, doctor list updates and appointment booking.

### Task 3 – From Sketch to Layout
Developed a Campus Library Search System.
Implemented book searching, category selection, navigation and reservation features using layout managers.

### Task 4 – Event-Handling Forensics
Created a Java Drawing Pad.
Implemented mouse click events, click counting, point storage and repainting.

### Task 5 – Same Screen, Different Event Styles
Developed a Currency Converter.
Demonstrated ActionListener, Inner Class, Anonymous Inner Class and Lambda Expression.

### Task 6 – Design Challenge
Created a Campus Event Registration System.
Implemented student registration, validation, duplicate checking and event filtering using Java Swing.

## Technologies Used
- Java
- Java Swing
- AWT
- Event Handling
- VS Code

## How to Run

Open the respective task folder in the terminal.

Example for Task 1:

```bash
cd Task01
javac FeeService.java FeePaymentGUI.java
java FeePaymentGUI