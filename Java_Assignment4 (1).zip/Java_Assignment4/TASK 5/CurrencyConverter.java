import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CurrencyConverter extends JFrame implements ActionListener {

    JTextField amountField;
    JLabel resultLabel;
    JButton convertButton;

    public CurrencyConverter() {

        setTitle("Currency Converter");
        setSize(450, 300);
        setLayout(new GridLayout(4, 2, 10, 15));

        add(new JLabel("Enter Amount (INR):"));

        amountField = new JTextField();
        add(amountField);

        add(new JLabel("Convert INR to USD:"));

        convertButton = new JButton("Convert");
        add(convertButton);

        resultLabel = new JLabel("Converted Amount: ");
        add(resultLabel);

        JButton clearButton = new JButton("Clear");
        add(clearButton);

        // 1. Frame implements ActionListener
        convertButton.addActionListener(this);

        // 2. Named Inner Class
        clearButton.addActionListener(new ClearListener());

        // 3. Anonymous Inner Class
        amountField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                convertCurrency();
            }
        });

        // 4. Lambda Expression
        convertButton.addActionListener(e -> {
            convertCurrency();
        });

        // WindowAdapter
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.out.println("Currency Converter Closed");
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    // Frame ActionListener
    @Override
    public void actionPerformed(ActionEvent e) {
        convertCurrency();
    }

    // Currency conversion method
    void convertCurrency() {
        try {
            double inr = Double.parseDouble(amountField.getText());

            if (inr <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Enter a valid positive amount!");
                return;
            }

            // Sample exchange rate: 1 USD = 85 INR
            double usd = inr / 85.0;

            resultLabel.setText(
                    String.format("Converted Amount: $%.2f", usd));

            JOptionPane.showMessageDialog(this,
                    String.format("INR %.2f = USD %.2f", inr, usd));

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a valid number!");
        }
    }

    // Named Inner Class
    class ClearListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            amountField.setText("");
            resultLabel.setText("Converted Amount: ");
        }
    }

    public static void main(String[] args) {
        new CurrencyConverter();
    }
}