import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class LibrarySearch extends JFrame {

    JTextField searchField;
    JComboBox<String> categoryBox;
    JTextArea resultArea;
    JLabel statusLabel;

    JButton prevButton, nextButton, reserveButton;

    ArrayList<String> books = new ArrayList<>();

    int currentPage = 0;

    public LibrarySearch() {

        setTitle("Campus Library Search System");
        setSize(650, 450);
        setLayout(new BorderLayout(10, 10));

        // TOP PANEL
        JPanel topPanel = new JPanel(new BorderLayout());

        JLabel title = new JLabel(
            "CAMPUS LIBRARY SEARCH",
            JLabel.CENTER
        );

        title.setFont(new Font("Arial", Font.BOLD, 22));

        topPanel.add(title, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel(new FlowLayout());

        searchField = new JTextField(15);

        String[] categories = {
            "All", "Java", "Python", "Database", "Networking"
        };

        categoryBox = new JComboBox<>(categories);

        JButton searchButton = new JButton("Search");

        searchPanel.add(new JLabel("Search Book:"));
        searchPanel.add(searchField);

        searchPanel.add(new JLabel("Category:"));
        searchPanel.add(categoryBox);

        searchPanel.add(searchButton);

        topPanel.add(searchPanel, BorderLayout.CENTER);

        add(topPanel, BorderLayout.NORTH);

        // CENTER PANEL
        resultArea = new JTextArea();

        resultArea.setEditable(false);

        resultArea.setFont(new Font("Arial", Font.PLAIN, 16));

        JScrollPane scrollPane = new JScrollPane(resultArea);

        add(scrollPane, BorderLayout.CENTER);

        // BOTTOM PANEL
        JPanel bottomPanel = new JPanel(new BorderLayout());

        JPanel buttonPanel = new JPanel(new FlowLayout());

        prevButton = new JButton("Previous");
        nextButton = new JButton("Next");
        reserveButton = new JButton("Reserve");

        buttonPanel.add(prevButton);
        buttonPanel.add(nextButton);
        buttonPanel.add(reserveButton);

        bottomPanel.add(buttonPanel, BorderLayout.CENTER);

        statusLabel = new JLabel("Status: Ready");

        bottomPanel.add(statusLabel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);

        // BOOK DATA
        books.add("Java Programming - Java");
        books.add("Python Basics - Python");
        books.add("Database Management - Database");
        books.add("Data Structures - Java");
        books.add("Computer Networks - Networking");
        books.add("Advanced Python - Python");
        books.add("SQL Fundamentals - Database");
        books.add("Java Advanced - Java");

        displayBooks();

        // SEARCH EVENT
        searchButton.addActionListener(e -> {

            String keyword = searchField.getText().toLowerCase();

            String category =
                categoryBox.getSelectedItem().toString();

            resultArea.setText("");

            for (String book : books) {

                boolean matchName =
                    book.toLowerCase().contains(keyword);

                boolean matchCategory =
                    category.equals("All")
                    || book.endsWith(category);

                if (matchName && matchCategory) {
                    resultArea.append(book + "\n");
                }
            }

            if (resultArea.getText().isEmpty()) {
                resultArea.setText("No books found!");
                statusLabel.setText("Status: No Results");
            } else {
                statusLabel.setText("Status: Search Completed");
            }
        });

        // PREVIOUS BUTTON
        prevButton.addActionListener(e -> {

            currentPage = 0;
            displayBooks();

            statusLabel.setText("Previous Page");
        });

        // NEXT BUTTON
        nextButton.addActionListener(e -> {

            currentPage = 1;
            displayNextBooks();

            statusLabel.setText("Next Page");
        });

        // RESERVE BUTTON
        reserveButton.addActionListener(e -> {

            String selected = resultArea.getSelectedText();

            if (selected == null || selected.trim().isEmpty()) {

                JOptionPane.showMessageDialog(
                    this, "Select a book from the results first!"
                );

            } else {

                JOptionPane.showMessageDialog(
                    this,
                    "Book Reserved Successfully!\n" + selected
                );

                statusLabel.setText("Status: Book Reserved");
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLocationRelativeTo(null);

        setVisible(true);
    }

    // DISPLAY FIRST BOOKS
    void displayBooks() {

        resultArea.setText("");

        for (int i = 0; i < 4; i++) {
            resultArea.append((i + 1) + ". " + books.get(i) + "\n");
        }
    }

    // DISPLAY NEXT BOOKS
    void displayNextBooks() {

        resultArea.setText("");

        for (int i = 4; i < books.size(); i++) {
            resultArea.append((i + 1) + ". " + books.get(i) + "\n");
        }
    }

    public static void main(String[] args) {

        new LibrarySearch();

    }
}