import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class DrawingPad extends JFrame {

    ArrayList<Point> points = new ArrayList<>();
    JLabel countLabel;
    JPanel drawingPanel;

    public DrawingPad() {

        setTitle("Java Drawing Pad");
        setSize(600, 450);
        setLayout(new BorderLayout());

        countLabel = new JLabel("Total Clicks: 0");
        countLabel.setFont(new Font("Arial", Font.BOLD, 16));
        countLabel.setHorizontalAlignment(JLabel.CENTER);

        add(countLabel, BorderLayout.NORTH);

        drawingPanel = new JPanel() {

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                g.setColor(Color.BLUE);

                for (Point p : points) {
                    g.fillOval(p.x - 5, p.y - 5, 10, 10);
                }
            }
        };

        drawingPanel.setBackground(Color.WHITE);
        add(drawingPanel, BorderLayout.CENTER);

        drawingPanel.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {

                points.add(e.getPoint());

                countLabel.setText(
                    "Total Clicks: " + points.size()
                );

                drawingPanel.repaint();
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new DrawingPad();
    }
}