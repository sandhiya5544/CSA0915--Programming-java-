import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class HospitalAppointment extends JFrame {

    JTextField patientField;
    JComboBox<String> departmentBox;
    JComboBox<String> doctorBox;

    public HospitalAppointment() {

        setTitle("Hospital Appointment Booking System");
        setSize(500, 350);
        setLayout(new GridLayout(5, 2, 10, 15));

        // Patient Name
        add(new JLabel("Patient Name:"));
        patientField = new JTextField();
        add(patientField);

        // Department
        add(new JLabel("Select Department:"));

        String[] departments = {
            "Cardiology", "Neurology", "Orthopedics"
        };

        departmentBox = new JComboBox<>(departments);
        add(departmentBox);

        // Doctor
        add(new JLabel("Select Doctor:"));

        doctorBox = new JComboBox<>();
        add(doctorBox);

        // Buttons
        JButton bookButton = new JButton("Book Appointment");
        JButton resetButton = new JButton("Reset");

        add(bookButton);
        add(resetButton);

        JLabel infoLabel = new JLabel("Select details and book appointment");
        add(infoLabel);

        // Display doctors immediately
        updateDoctors();

        // Department selection
        departmentBox.addActionListener(e -> updateDoctors());

        // Book Appointment
        bookButton.addActionListener(e -> {

            String name = patientField.getText().trim();

            if (name.isEmpty()) {

                JOptionPane.showMessageDialog(
                    this, "Please enter patient name!"
                );

            } else {

                JOptionPane.showMessageDialog(
                    this,
                    "Appointment Booked Successfully!\n\n"
                    + "Patient: " + name
                    + "\nDepartment: " + departmentBox.getSelectedItem()
                    + "\nDoctor: " + doctorBox.getSelectedItem()
                );

                infoLabel.setText("Appointment Booked Successfully!");
            }
        });

        // Reset
        resetButton.addActionListener(e -> {

            patientField.setText("");
            departmentBox.setSelectedIndex(0);
            updateDoctors();
            infoLabel.setText("Select details and book appointment");

        });

        // Window Event
        addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                System.out.println("Hospital Window Closed");
            }

        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    // Doctor List Updating Method
    private void updateDoctors() {

        doctorBox.removeAllItems();

        String department =
            (String) departmentBox.getSelectedItem();

        if (department == null) return;

        switch (department) {

            case "Cardiology":
                doctorBox.addItem("Dr. Arun - Heart Specialist");
                doctorBox.addItem("Dr. Meena - Cardiologist");
                break;

            case "Neurology":
                doctorBox.addItem("Dr. Priya - Neurologist");
                doctorBox.addItem("Dr. Ravi - Brain Specialist");
                break;

            case "Orthopedics":
                doctorBox.addItem("Dr. Kumar - Bone Specialist");
                doctorBox.addItem("Dr. Anitha - Orthopedic");
                break;
        }
    }

    public static void main(String[] args) {

        new HospitalAppointment();

    }
}