public class FeeService {

    public String processPayment(String name, double amount) {

        if (name.trim().isEmpty()) {
            return "Please enter student name!";
        }

        if (amount <= 0) {
            return "Please enter a valid amount!";
        }

        return "Payment Successful!\n"
                + "Student Name: " + name
                + "\nAmount Paid: Rs. " + amount;
    }
}