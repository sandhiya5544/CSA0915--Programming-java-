import javax.swing.*;
import java.awt.*;

public class FeePaymentGUI extends JFrame {

    JTextField nameField, amountField;
    JLabel statusLabel;

    FeeService service = new FeeService();

    String paymentReceipt = "No payment completed yet.";

    public FeePaymentGUI() {

        setTitle("Student Fee Payment System");
        setSize(450, 300);
        setLayout(new GridLayout(5, 2, 10, 10));

        add(new JLabel("Student Name:"));
        nameField = new JTextField();
        add(nameField);

        add(new JLabel("Fee Amount:"));
        amountField = new JTextField();
        add(amountField);

        JButton payButton = new JButton("Pay Now");
        JButton resetButton = new JButton("Reset");

        add(payButton);
        add(resetButton);

        JButton receiptButton = new JButton("View Receipt");
        JButton exitButton = new JButton("Exit");

        add(receiptButton);
        add(exitButton);

        statusLabel = new JLabel("Enter payment details");
        add(statusLabel);

        // Pay Button
        payButton.addActionListener(e -> {

            try {

                String name = nameField.getText();
                String amountText = amountField.getText();

                if (amountText.trim().isEmpty()) {
                    statusLabel.setText("Enter payment amount!");
                    return;
                }

                double amount = Double.parseDouble(amountText);

                paymentReceipt = service.processPayment(name, amount);

                statusLabel.setText(paymentReceipt.replace("\n", " | "));

            } catch (NumberFormatException ex) {

                statusLabel.setText("Invalid amount!");
            }
        });

        // Reset Button
        resetButton.addActionListener(e -> {

            nameField.setText("");
            amountField.setText("");
            statusLabel.setText("Enter payment details");

        });

        // Receipt Button
        receiptButton.addActionListener(e -> {

            JOptionPane.showMessageDialog(
                    this,
                    paymentReceipt,
                    "Payment Receipt",
                    JOptionPane.INFORMATION_MESSAGE
            );

        });

        // Exit Button
        exitButton.addActionListener(e -> dispose());

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {

        new FeePaymentGUI();

    }
}