import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;

public class EventRegistrationApp extends JFrame {

    JTextField nameField, emailField;
    JComboBox<String> eventBox, filterBox;
    DefaultTableModel model;
    JTable table;
    TableRowSorter<DefaultTableModel> sorter;

    public EventRegistrationApp() {

        setTitle("Campus Event Registration System");
        setSize(800, 550);
        setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel(
            "CAMPUS EVENT REGISTRATION SYSTEM",
            JLabel.CENTER
        );
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(15, 5, 15, 5));
        add(title, BorderLayout.NORTH);

        // Registration Form
        JPanel form = new JPanel(new GridLayout(4, 2, 10, 10));
        form.setBorder(BorderFactory.createTitledBorder("Student Registration"));

        nameField = new JTextField(20);
        emailField = new JTextField(20);

        eventBox = new JComboBox<>(new String[]{
            "Technical Symposium",
            "Coding Competition",
            "Workshop",
            "Cultural Fest"
        });

        JButton registerButton = new JButton("Register");
        JButton clearButton = new JButton("Clear");

        form.add(new JLabel("Student Name:"));
        form.add(nameField);

        form.add(new JLabel("Email Address:"));
        form.add(emailField);

        form.add(new JLabel("Select Event:"));
        form.add(eventBox);

        form.add(registerButton);
        form.add(clearButton);

        // Registration Table
        model = new DefaultTableModel(
            new String[]{"Student Name", "Email", "Event"}, 0
        );

        table = new JTable(model);
        sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(
            BorderFactory.createTitledBorder("Registered Students")
        );

        // Filter Panel
        JPanel bottomPanel = new JPanel(new FlowLayout());

        filterBox = new JComboBox<>(new String[]{
            "All Events",
            "Technical Symposium",
            "Coding Competition",
            "Workshop",
            "Cultural Fest"
        });

        JButton filterButton = new JButton("Filter");

        bottomPanel.add(new JLabel("Filter Event:"));
        bottomPanel.add(filterBox);
        bottomPanel.add(filterButton);

        // Main Layout
        JPanel topPanel = new JPanel(new BorderLayout(10, 10));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        topPanel.add(form, BorderLayout.CENTER);

        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Register Button
        registerButton.addActionListener(e -> {

            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String event = eventBox.getSelectedItem().toString();

            if (name.isEmpty() || email.isEmpty()) {
                JOptionPane.showMessageDialog(
                    this, "Please enter all details!"
                );
                return;
            }

            if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                JOptionPane.showMessageDialog(
                    this, "Enter a valid email address!"
                );
                return;
            }

            for (int i = 0; i < model.getRowCount(); i++) {
                if (model.getValueAt(i, 1).equals(email)
                    && model.getValueAt(i, 2).equals(event)) {

                    JOptionPane.showMessageDialog(
                        this, "Student already registered!"
                    );
                    return;
                }
            }

            model.addRow(new Object[]{name, email, event});

            JOptionPane.showMessageDialog(
                this, "Registration Successful!"
            );

            nameField.setText("");
            emailField.setText("");
        });

        // Clear Button
        clearButton.addActionListener(e -> {
            nameField.setText("");
            emailField.setText("");
        });

        // Filter Button
        filterButton.addActionListener(e -> {
            String selected = filterBox.getSelectedItem().toString();

            if (selected.equals("All Events")) {
                sorter.setRowFilter(null);
            } else {
                sorter.setRowFilter(
                    RowFilter.regexFilter(
                        "^" + java.util.regex.Pattern.quote(selected) + "$",
                        2
                    )
                );
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new EventRegistrationApp();
    }
}