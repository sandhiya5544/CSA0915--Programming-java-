import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;

public class PassLoader {
    static final int BATCH = 1000;
    static final String SQL = "INSERT INTO bus_pass (pass_id, reg_no, "
        + "student_name, route_no, boarding_stop, valid_until, amount_paid) "
        + "VALUES (?,?,?,?,?,?,?)";

    interface Load { void run(Connection c, List<PassRecord> rows)
        throws SQLException; }

    static List<PassRecord> generate(int n) {
        List<PassRecord> list = new ArrayList<>(n);
        for (int i = 1; i <= n; i++)
            list.add(new PassRecord(String.format("P%06d", i),
                String.format("19%07d", i), "Student " + i, 1 + i % 20,
                "Stop " + (i % 50), LocalDate.of(2027, 3, 31),
                new BigDecimal("18500.00")));
        return list;
    }

    static void bind(PreparedStatement ps, PassRecord r) throws SQLException {
        ps.setString(1, r.passId());
        ps.setString(2, r.regNo());
        ps.setString(3, r.name());
        ps.setInt(4, r.routeNo());
        ps.setString(5, r.stop());
        ps.setDate(6, java.sql.Date.valueOf(r.validUntil()));
        ps.setBigDecimal(7, r.amount());
    }

    /** Approach 1: Statement, SQL text built for every row (measurement only). */
    static void viaStatement(Connection c, List<PassRecord> rows)
            throws SQLException {
        try (Statement st = c.createStatement()) {
            for (PassRecord r : rows)
                st.executeUpdate("INSERT INTO bus_pass VALUES ('" + r.passId()
                    + "','" + r.regNo() + "','" + r.name() + "'," + r.routeNo()
                    + ",'" + r.stop() + "','" + r.validUntil() + "',"
                    + r.amount() + ")");
        }
    }

    /** Approach 2: PreparedStatement, one executeUpdate per row. */
    static void viaPrepared(Connection c, List<PassRecord> rows)
            throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(SQL)) {   // TODO 1
            for (PassRecord r : rows) {
                bind(ps, r);
                ps.executeUpdate();
            }
        }
    }

    /** Approach 3: PreparedStatement batch, executed every 1,000 rows. */
    static void viaBatch(Connection c, List<PassRecord> rows)
            throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(SQL)) {
            int n = 0;
            for (PassRecord r : rows) {
                bind(ps, r);
                ps.addBatch();                                    // TODO 2
                if (++n % BATCH == 0) ps.executeBatch();          // TODO 3
            }
            if (n % BATCH != 0) ps.executeBatch();      // remaining rows
        }
    }

    static void truncate(Connection c) throws SQLException {
        try (Statement st = c.createStatement()) {
            st.execute("TRUNCATE TABLE bus_pass");
        }
    }

    /** Times one load in milliseconds, in auto-commit or one transaction. */
    static double timeMs(Connection c, Load load, List<PassRecord> rows,
                         boolean oneTransaction) throws SQLException {
        truncate(c);
        c.setAutoCommit(!oneTransaction);
        long t0 = System.nanoTime();
        try {
            load.run(c, rows);
            if (oneTransaction) c.commit();
        } catch (SQLException | RuntimeException e) {
            if (oneTransaction) c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
        return (System.nanoTime() - t0) / 1e6;
    }

    static long count(Connection c) throws SQLException {
        try (Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM bus_pass")) {
            rs.next();
            return rs.getLong(1);
        }
    }

    /** Verify contents and column types with SELECT + ResultSetMetaData. */
    static void describe(Connection c) throws SQLException {
        try (Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(
                 "SELECT * FROM bus_pass ORDER BY pass_id LIMIT 10")) {
            ResultSetMetaData md = rs.getMetaData();
            for (int i = 1; i <= md.getColumnCount(); i++)
                System.out.printf("%-14s %-10s precision=%d nullable=%d%n",
                    md.getColumnLabel(i), md.getColumnTypeName(i),
                    md.getPrecision(i), md.isNullable(i));
            while (rs.next())
                System.out.println(rs.getString("pass_id") + " | "
                    + rs.getString("student_name") + " | "
                    + rs.getDate("valid_until") + " | "
                    + rs.getBigDecimal("amount_paid"));
        }
    }

    /** Invalid amount in the 6th of 10 lines: auto-commit vs one transaction. */
    static void failureTest(Connection c, boolean oneTransaction)
            throws SQLException {
        List<String> lines = new ArrayList<>();
        for (PassRecord r : generate(10)) lines.add(r.toLine());
        lines.set(5, lines.get(5).replaceAll("[^,]*$", "abc"));
        truncate(c);
        c.setAutoCommit(!oneTransaction);
        try (PreparedStatement ps = c.prepareStatement(SQL)) {
            int n = 0;
            for (String line : lines) {
                n++;
                PassRecord r = PassRecord.parse(line);
                if (r == null) throw new IllegalArgumentException(
                    "line " + n + ": " + PassRecord.check(line));
                bind(ps, r);
                ps.executeUpdate();
            }
            if (oneTransaction) c.commit();
        } catch (Exception e) {
            System.out.println("Failure: " + e.getMessage());
            if (oneTransaction) c.rollback();
        } finally {
            c.setAutoCommit(true);
        }
        System.out.println((oneTransaction ? "Transaction" : "Auto-commit")
            + " -> rows in table: " + count(c));
    }

    public static void main(String[] args) throws Exception {
        try (Connection c = Db.open()) {
            List<PassRecord> ten = generate(10);
            truncate(c); viaStatement(c, ten);
            System.out.println("Statement rows: " + count(c));
            truncate(c); viaPrepared(c, ten);
            System.out.println("PreparedStatement rows: " + count(c));
            truncate(c); viaBatch(c, ten);
            System.out.println("Batch rows: " + count(c));
            describe(c);
            failureTest(c, false);
            failureTest(c, true);
            for (int n : new int[] {1000, 10000, 100000}) {
                List<PassRecord> rows = generate(n);
                System.out.printf("n=%d Statement=%.0f ms Prepared=%.0f ms "
                    + "Batch=%.0f ms%n", n,
                    timeMs(c, PassLoader::viaStatement, rows, false),
                    timeMs(c, PassLoader::viaPrepared, rows, false),
                    timeMs(c, PassLoader::viaBatch, rows, false));
                System.out.printf("n=%d one transaction: Prepared=%.0f ms "
                    + "Batch=%.0f ms%n", n,
                    timeMs(c, PassLoader::viaPrepared, rows, true),
                    timeMs(c, PassLoader::viaBatch, rows, true));
            }
        }
    }
}
