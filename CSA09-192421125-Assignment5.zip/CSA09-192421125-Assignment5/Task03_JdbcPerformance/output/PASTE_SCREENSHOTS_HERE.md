# Task 03 – B3 JDBC Performance, Transactions – paste your output screenshots in this folder

Save each screenshot as a PNG with the file name shown. Each screenshot must show the
command, the input and the COMPLETE output (a screenshot of only a final message is not enough).

- 01_create_table.png           (SHOW CREATE TABLE bus_pass)
- 02_ten_record_inserts.png     (Statement, PreparedStatement, batch: 10 rows each)
- 03_resultsetmetadata.png      (SELECT output and column types)
- 04_timings_autocommit.png     (Table A: 1,000 / 10,000 / 100,000 rows)
- 05_timings_transaction.png    (Table B and driver options Table C)
- 06_failure_rollback.png       (auto-commit leaves 5 rows, transaction leaves 0; SELECT COUNT(*))

Also save raw timing values (CSV) here and link them from the main README.md.
