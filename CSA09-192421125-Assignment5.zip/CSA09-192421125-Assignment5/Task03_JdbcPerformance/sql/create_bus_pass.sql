CREATE DATABASE IF NOT EXISTS transport_test CHARACTER SET utf8mb4;
USE transport_test;
CREATE TABLE IF NOT EXISTS bus_pass (
  pass_id        VARCHAR(10)   NOT NULL,
  reg_no         VARCHAR(12)   NOT NULL,
  student_name   VARCHAR(60)   NOT NULL,
  route_no       INT           NOT NULL,
  boarding_stop  VARCHAR(40)   NOT NULL,
  valid_until    DATE          NOT NULL,
  amount_paid    DECIMAL(8,2)  NOT NULL,
  PRIMARY KEY (pass_id),
  CONSTRAINT chk_amount CHECK (amount_paid >= 0),
  INDEX idx_route (route_no)
) ENGINE=InnoDB;
