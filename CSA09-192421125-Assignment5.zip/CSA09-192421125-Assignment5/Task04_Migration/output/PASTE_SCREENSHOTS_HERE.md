# Task 04 – B4 Final Engineering Decision (Migration) – paste your output screenshots in this folder

Save each screenshot as a PNG with the file name shown. Each screenshot must show the
command, the input and the COMPLETE output (a screenshot of only a final message is not enough).

- 01_migration_output.png       (Lines read / loaded / rejected, COUNT(*))
- 02_rejects_txt.png            (contents of rejects.txt)
- 03_databasemetadata.png       (product, driver version, tables)
- 04_migration_timing.png       (100,000 generated records)

Also save raw timing values (CSV) here and link them from the main README.md.
