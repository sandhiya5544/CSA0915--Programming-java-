import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

public class Migrator {
    public static void main(String[] args) throws Exception {
        String src = args.length > 0 ? args[0] : "passes.txt";
        Set<String> seen = new HashSet<>();
        long lineNo = 0, loaded = 0, rejected = 0;
        try (Connection c = Db.open();
             BufferedReader br = new BufferedReader(new InputStreamReader(
                 Files.newInputStream(Paths.get(src)), StandardCharsets.UTF_8));
             BufferedWriter rej = Files.newBufferedWriter(
                 Paths.get("rejects.txt"), StandardCharsets.UTF_8);
             PreparedStatement ps = c.prepareStatement(PassLoader.SQL)) {
            c.setAutoCommit(false);                    // one transaction
            try {
                String line;
                int inBatch = 0;
                while ((line = br.readLine()) != null) {
                    lineNo++;
                    String why = PassRecord.check(line);
                    PassRecord r = (why == null) ? PassRecord.parse(line) : null;
                    if (r != null && !seen.add(r.passId())) {
                        why = "duplicate pass ID";
                        r = null;
                    }
                    if (r == null) {                    // report, do not load
                        rej.write(lineNo + " | " + why + " | " + line + "\n");
                        rejected++;
                        continue;
                    }
                    PassLoader.bind(ps, r);
                    ps.addBatch();
                    loaded++;
                    if (++inBatch == PassLoader.BATCH) {
                        ps.executeBatch();
                        inBatch = 0;
                    }
                }
                if (inBatch > 0) ps.executeBatch();
                c.commit();                              // all or nothing
            } catch (Exception e) {
                c.rollback();
                System.out.println("ROLLED BACK: " + e);
                throw e;
            }
            System.out.println("Lines read: " + lineNo + ", loaded: " + loaded
                + ", rejected: " + rejected);
            System.out.println("Rows now in bus_pass: " + PassLoader.count(c));
            report(c);
        }
    }

    static void report(Connection c) throws SQLException {
        DatabaseMetaData md = c.getMetaData();
        System.out.println("Database : " + md.getDatabaseProductName() + " "
            + md.getDatabaseProductVersion());
        System.out.println("Driver   : " + md.getDriverName() + " "
            + md.getDriverVersion());
        try (ResultSet rs = md.getTables(c.getCatalog(), null, "%",
                new String[] {"TABLE"})) {
            while (rs.next())
                System.out.println("Table    : " + rs.getString("TABLE_NAME"));
        }
    }
}
