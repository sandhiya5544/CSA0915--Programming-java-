# Task 01 – B1 File Store and Alternative Design – paste your output screenshots in this folder

Save each screenshot as a PNG with the file name shown. Each screenshot must show the
command, the input and the COMPLETE output (a screenshot of only a final message is not enough).

- 01_compile_and_run_demo.png   (javac + java PassStoreDemo: P1003 record, null for P1002, null for P9999, damaged count, route 12, add, duplicate, missing file)
- 02_linecount_timings.png      (1 MB, 10 MB, 50 MB: unbuffered vs buffered vs readAllLines)
- 03_read_call_counts.png       (CountingInputStream results vs prediction s+1 and ceil(s/8192)+1)
- 04_search_timings.png         (find() time for 1,000 / 5,000 / 10,000 / 50,000 / 100,000 records)
- 05_hashmap_comparison.png     (scan vs HashMap: time and memory)
- 06_memory_test_Xmx64m.png     (readAllLines with restricted heap)

Also save raw timing values (CSV) here and link them from the main README.md.
