import java.util.*;

public class Bench {
    interface Job { Object run() throws Exception; }

    /** Median of 'runs' timings in milliseconds (first run is a warm-up). */
    static double medianMs(Job job, int runs) throws Exception {
        job.run();                                   // warm-up, not recorded
        double[] t = new double[runs];
        for (int i = 0; i < runs; i++) {
            long t0 = System.nanoTime();
            job.run();
            t[i] = (System.nanoTime() - t0) / 1e6;
        }
        Arrays.sort(t);
        return t[runs / 2];
    }

    public static void main(String[] args) throws Exception {
        long mb = 1024L * 1024;
        for (int size : new int[] {1, 10, 50}) {
            String f = "log_" + size + "mb.txt";
            FileGen.bytes(f, size * mb);
            System.out.printf("%d MB  unbuffered=%.1f ms  buffered8K=%.1f ms"
                + "  readAllLines=%.1f ms%n", size,
                medianMs(() -> LineCounter.countUnbuffered(f), 5),
                medianMs(() -> LineCounter.countBuffered(f, 8192), 5),
                medianMs(() -> LineCounter.countReadAllLines(f), 5));
        }
        for (int n : new int[] {1000, 5000, 10000, 50000, 100000}) {
            String f = "passes_" + n + ".txt";
            FileGen.records(f, n);
            PassStore s = new PassStore(f);
            String last = String.format("P%06d", n);
            double scanFound = medianMs(() -> s.find(last), 5);
            double scanMiss = medianMs(() -> s.find("P999999"), 5);
            double load = medianMs(() -> new HashMapPassStore(f), 5);
            HashMapPassStore h = new HashMapPassStore(f);
            double look = medianMs(() -> h.find(last), 5);
            System.out.printf("n=%d scanLast=%.2f ms scanMiss=%.2f ms"
                + " mapLoad=%.2f ms mapLookup=%.4f ms%n",
                n, scanFound, scanMiss, load, look);
        }
    }
}
