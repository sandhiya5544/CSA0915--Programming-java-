import java.nio.file.*;
import java.util.List;

public class PassStoreDemo {
    public static void main(String[] args) throws Exception {
        Path p = Paths.get("passes_demo.txt");
        Files.write(p, List.of(
            "P1001,192421001,Anand R,12,Ambattur,2027-03-31,18500.00",
            "P1002,192421002,Meena K,7,Avadi,2027-03-31",
            "P1003,192421003,Karthik S,12,Padi,2027-03-31,18500.00"));
        PassStore s = new PassStore(p.toString());
        System.out.println(s.find("P1003"));      // normal case
        System.out.println(s.find("P1002"));      // damaged line -> null
        System.out.println(s.find("P9999"));      // ID does not exist -> null
        System.out.println("Damaged lines skipped: " + s.lastDamagedCount());
        System.out.println("Route 12: " + s.listByRoute(12).size() + " passes");
        System.out.println("Add P1004: " + s.add(new PassRecord("P1004",
            "192421004", "Divya M", 5, "Avadi",
            java.time.LocalDate.of(2027, 3, 31),
            new java.math.BigDecimal("17500.00"))));
        System.out.println("Add duplicate P1001: " + s.add(new PassRecord("P1001",
            "192421001", "Anand R", 12, "Ambattur",
            java.time.LocalDate.of(2027, 3, 31),
            new java.math.BigDecimal("18500.00"))));
        try { new PassStore("no_such_file.txt").find("P1001"); }
        catch (NoSuchFileException e) {
            System.out.println("Missing file: " + e.getMessage());
        }
    }
}
