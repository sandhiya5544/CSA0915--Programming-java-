import java.io.*;
import java.nio.file.*;

public class LineCounter {
    /** One read() call per byte: the slow original. */
    public static long countUnbuffered(String path) throws IOException {
        long count = 0; int last = -1, b;
        try (InputStream in = new FileInputStream(path)) {
            while ((b = in.read()) != -1) {
                if (b == '\n') count++;
                last = b;
            }
        }
        return (last != -1 && last != '\n') ? count + 1 : count;
    }

    /** Reads blocks of 'size' bytes into a byte array. */
    public static long countBuffered(String path, int size) throws IOException {
        long count = 0; int last = -1, n;
        byte[] buf = new byte[size];
        try (InputStream in = new FileInputStream(path)) {
            while ((n = in.read(buf)) != -1) {
                for (int i = 0; i < n; i++) if (buf[i] == '\n') count++;
                last = buf[n - 1] & 0xFF;
            }
        }
        return (last != -1 && last != '\n') ? count + 1 : count;
    }

    public static long countReadAllLines(String path) throws IOException {
        return Files.readAllLines(Paths.get(path)).size();
    }

    /** Instrumented: how many read calls reach the file stream? */
    public static long readCalls(String path, boolean buffered)
            throws IOException {
        try (CountingInputStream cs =
                 new CountingInputStream(new FileInputStream(path));
             InputStream in = buffered ? new BufferedInputStream(cs, 8192) : cs) {
            while (in.read() != -1) { /* read byte by byte on purpose */ }
            return cs.calls;
        }
    }
}
