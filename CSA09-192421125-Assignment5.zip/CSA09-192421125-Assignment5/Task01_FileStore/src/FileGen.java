import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public class FileGen {
    static String line(int i) {
        return String.format(
            "P%06d,19%07d,Student %d,%d,Stop %d,2027-03-31,18500.00",
            i, i, i, 1 + i % 20, i % 50);
    }

    /** n valid records, one per line. */
    public static void records(String path, int n) throws IOException {
        try (BufferedWriter w = Files.newBufferedWriter(Paths.get(path),
                StandardCharsets.UTF_8)) {
            for (int i = 1; i <= n; i++) { w.write(line(i)); w.write('\n'); }
        }
    }

    /** Lines until the file is at least targetBytes long. */
    public static void bytes(String path, long targetBytes) throws IOException {
        long size = 0; int i = 1;
        try (BufferedWriter w = Files.newBufferedWriter(Paths.get(path),
                StandardCharsets.UTF_8)) {
            while (size < targetBytes) {
                String s = line(i++);
                w.write(s); w.write('\n');
                size += s.length() + 1;
            }
        }
    }
}
