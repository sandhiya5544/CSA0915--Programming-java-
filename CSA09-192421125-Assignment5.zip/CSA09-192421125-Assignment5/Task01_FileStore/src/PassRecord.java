import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public record PassRecord(String passId, String regNo, String name, int routeNo,
                         String stop, LocalDate validUntil, BigDecimal amount) {

    public static final int FIELDS = 7;

    /** Returns null if the line is usable, otherwise the reason it is damaged. */
    public static String check(String line) {
        if (line == null || line.isBlank()) return "empty line";
        String[] f = line.split(",", -1);
        if (f.length != FIELDS) return "wrong field count: " + f.length;
        for (int i : new int[] {0, 1, 2, 4})
            if (f[i].isBlank()) return "empty field " + (i + 1);
        if (f[0].length() > 10 || f[1].length() > 12
                || f[2].length() > 60 || f[4].length() > 40)
            return "field too long";
        try { Integer.parseInt(f[3].trim()); }
        catch (NumberFormatException e) { return "route is not a number"; }
        try { LocalDate.parse(f[5].trim()); }
        catch (DateTimeParseException e) { return "invalid date"; }
        try {
            BigDecimal a = new BigDecimal(f[6].trim());
            if (a.signum() < 0) return "negative amount";
            if (a.scale() > 2) return "more than 2 decimal places";
            if (a.compareTo(new BigDecimal("999999.99")) > 0)
                return "amount out of range";
        } catch (NumberFormatException e) { return "amount is not a number"; }
        return null;
    }

    /** Returns the record, or null if the line is damaged. */
    public static PassRecord parse(String line) {
        if (check(line) != null) return null;
        String[] f = line.split(",", -1);
        return new PassRecord(f[0].trim(), f[1].trim(), f[2].trim(),
            Integer.parseInt(f[3].trim()), f[4].trim(),
            LocalDate.parse(f[5].trim()), new BigDecimal(f[6].trim()));
    }

    public String toLine() {
        return String.join(",", passId, regNo, name, Integer.toString(routeNo),
            stop, validUntil.toString(), amount.toPlainString());
    }
}
