import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Alternative design: load all valid records once, then answer in O(1). */
public class HashMapPassStore {
    private final Map<String, PassRecord> map = new HashMap<>();
    private int damaged;

    public HashMapPassStore(String path) throws IOException {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(
                Files.newInputStream(Paths.get(path)), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                PassRecord r = PassRecord.parse(line);
                if (r == null) { damaged++; continue; }
                map.putIfAbsent(r.passId(), r);     // first record wins
            }
        }
    }
    public PassRecord find(String passId) { return map.get(passId); }
    public int size() { return map.size(); }
    public int damagedCount() { return damaged; }
}
