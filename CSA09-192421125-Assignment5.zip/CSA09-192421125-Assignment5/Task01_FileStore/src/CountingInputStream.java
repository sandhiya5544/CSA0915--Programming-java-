import java.io.*;

/** Counts how many read calls reach the underlying stream. */
public class CountingInputStream extends FilterInputStream {
    public long calls;
    public CountingInputStream(InputStream in) { super(in); }
    @Override public int read() throws IOException {
        calls++; return in.read();
    }
    @Override public int read(byte[] b, int off, int len) throws IOException {
        calls++; return in.read(b, off, len);
    }
}
