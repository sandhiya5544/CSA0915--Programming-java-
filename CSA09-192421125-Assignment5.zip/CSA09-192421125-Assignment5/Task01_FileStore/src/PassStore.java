import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class PassStore {
    private final Path file;
    private int damaged;                    // damaged lines seen by last scan

    public PassStore(String path) { this.file = Paths.get(path); }

    public int lastDamagedCount() { return damaged; }

    /** Opens the file; invalid bytes are replaced, not thrown. */
    private BufferedReader open() throws IOException {
        return new BufferedReader(new InputStreamReader(
            Files.newInputStream(file), StandardCharsets.UTF_8));
    }

    /** Appends one record. Returns false if invalid or a duplicate ID. */
    public boolean add(PassRecord r) throws IOException {
        String line = r.toLine();
        if (line.indexOf('\n') >= 0 || line.indexOf('\r') >= 0
                || PassRecord.check(line) != null) return false;
        if (Files.exists(file) && find(r.passId()) != null) return false;
        try (BufferedWriter w = Files.newBufferedWriter(file,
                StandardCharsets.UTF_8, StandardOpenOption.CREATE,
                StandardOpenOption.APPEND)) {
            w.write(line + "\n");           // one write call per record
        }
        return true;
    }

    /** TODO 1 completed: read line by line, skip damaged lines, return match. */
    public PassRecord find(String passId) throws IOException {
        damaged = 0;
        try (BufferedReader br = open()) {
            String line;
            while ((line = br.readLine()) != null) {
                PassRecord r = PassRecord.parse(line);
                if (r == null) { damaged++; continue; }   // skip damaged line
                if (r.passId().equals(passId)) return r;  // matching record
            }
        }
        return null;                                      // not found
    }

    public List<PassRecord> listByRoute(int routeNo) throws IOException {
        List<PassRecord> out = new ArrayList<>();
        damaged = 0;
        try (BufferedReader br = open()) {
            String line;
            while ((line = br.readLine()) != null) {
                PassRecord r = PassRecord.parse(line);
                if (r == null) { damaged++; continue; }
                if (r.routeNo() == routeNo) out.add(r);
            }
        }
        return out;
    }
}
