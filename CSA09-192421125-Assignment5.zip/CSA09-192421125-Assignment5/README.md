# CSA09 – Programming in Java – Assignment 5 (CO5): Data Persistence Engineering

| Item | Value |
|---|---|
| Student name | Sandhiya B |
| Register number | 192421125 |
| Programme | B.Tech – Information Technology, SIMATS Engineering College |
| Java version | **[INSERT output of `java -version` and `javac -version`]** |
| MySQL / Connector-J | **[INSERT versions]** |
| Repository | `CSA09-192421125-Assignment5` – **[INSERT GitHub link]** |

Part A (A1–A5, design and pseudocode) is in the PDF/Word project report. Part B code is in the task folders below.
Every task folder has `src/` (Java), `input/` (test data), `sql/` (table scripts), `output/` (your screenshots – see `PASTE_SCREENSHOTS_HERE.md`).

## Compile and run

Tasks 02–04 need the MySQL Connector/J jar (`mysql-connector-j-x.y.z.jar`). On Windows use `;` instead of `:` in the classpath.
Set the database login first (never commit passwords):

    export DB_URL="jdbc:mysql://localhost:3306/transport_test"
    export DB_USER=root
    export DB_PASS=your_password
    # for batch experiments also try: ...transport_test?rewriteBatchedStatements=true

### Task01_FileStore (B1 – no database needed)

    cd Task01_FileStore/src && javac *.java
    cp ../input/passes_demo.txt .  # PassStoreDemo creates its own demo file; input is for reference
    java PassStoreDemo      # normal / damaged / missing-ID / missing-file tests
    java Bench              # line-count timings (1,10,50 MB) and search timings (1,000-100,000)
    # read-call counts: call LineCounter.readCalls(file, true/false) from a small test class

### Task02_Adversarial (B2)

    mysql -u root -p < ../sql/create_users.sql
    cd Task02_Adversarial/src
    javac -cp ".:/path/to/mysql-connector-j.jar" *.java
    java  -cp ".:/path/to/mysql-connector-j.jar" LoginDemo     # unsafe vs PreparedStatement login
    java  DamagedDemo                                          # damaged bus-pass data

### Task03_JdbcPerformance (B3)

    mysql -u root -p < ../sql/create_bus_pass.sql
    cd Task03_JdbcPerformance/src
    javac -cp ".:/path/to/mysql-connector-j.jar" *.java
    java  -cp ".:/path/to/mysql-connector-j.jar" PassLoader    # 10-row test, metadata, rollback test, timings

### Task04_Migration (B4)

    mysql -u root -p < ../sql/create_bus_pass.sql
    cd Task04_Migration/src
    javac -cp ".:/path/to/mysql-connector-j.jar" *.java
    java  -cp ".:/path/to/mysql-connector-j.jar" Migrator ../input/passes.txt

Expected for the sample `passes.txt`: 10 lines read, 2 loaded, 8 rejected (see report Section 4.6.4).

## Result notes (fill in AFTER you run each task – do not guess)

| Task | Result note |
|---|---|
| Task01 | [WRITE what you observed: outputs matched? timings?] |
| Task02 | [WRITE: which inputs fooled the unsafe login; PreparedStatement result] |
| Task03 | [WRITE: fastest approach per size; rows left after failure in each mode] |
| Task04 | [WRITE: loaded/rejected counts; storage decision] |

## Commit plan (one commit per task at least)

    git add Task01_FileStore && git commit -m "Task01: bus-pass file store and buffered counter"
    git add Task02_Adversarial && git commit -m "Task02: unsafe vs PreparedStatement login tests"
    git add Task03_JdbcPerformance && git commit -m "Task03: JDBC insertion comparison and rollback test"
    git add Task04_Migration && git commit -m "Task04: file-to-database migration"
    git add README.md && git commit -m "Add README"
