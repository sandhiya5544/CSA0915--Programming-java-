CREATE DATABASE IF NOT EXISTS transport_test CHARACTER SET utf8mb4;
USE transport_test;
CREATE TABLE IF NOT EXISTS users (
  user_id   INT AUTO_INCREMENT PRIMARY KEY,
  username  VARCHAR(30) NOT NULL UNIQUE,
  password  VARCHAR(60) NOT NULL   -- plain text ONLY in this throw-away lab DB
);
INSERT INTO users (username, password) VALUES ('admin','Admin@123'),('student1','pass123');
