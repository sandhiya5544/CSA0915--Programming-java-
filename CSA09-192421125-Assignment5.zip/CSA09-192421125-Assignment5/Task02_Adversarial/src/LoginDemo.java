import java.sql.*;

public class LoginDemo {
    /** UNSAFE: user input is joined into the SQL text. */
    static boolean unsafeLogin(Connection c, String user, String pass)
            throws SQLException {
        String sql = "SELECT user_id FROM users WHERE username = '" + user
                   + "' AND password = '" + pass + "'";
        System.out.println("  SQL sent: " + sql);
        try (Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            return rs.next();
        }
    }

    /** SAFE: the SQL text is fixed; input is bound as values. */
    static boolean safeLogin(Connection c, String user, String pass)
            throws SQLException {
        String sql = "SELECT user_id FROM users WHERE username = ? "
                   + "AND password = ?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, user);
            ps.setString(2, pass);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }

    public static void main(String[] args) throws Exception {
        String[][] cases = {
            {"admin", "Admin@123"},        // valid login
            {"admin", "wrong"},            // wrong password
            {"admin' -- ", "x"},           // comment injection
            {"nobody", "' OR '1'='1"},     // always-true injection
            {"o'brien", "x"},              // honest input with a quote
            {"", ""}                       // empty input
        };
        try (Connection c = Db.open()) {
            for (String[] t : cases) {
                System.out.println("user=[" + t[0] + "] pass=[" + t[1] + "]");
                String u;
                try { u = unsafeLogin(c, t[0], t[1]) ? "ACCEPTED" : "rejected"; }
                catch (SQLException e) { u = "SQL ERROR: " + e.getMessage(); }
                String s = safeLogin(c, t[0], t[1]) ? "ACCEPTED" : "rejected";
                System.out.println("  unsafe: " + u + "   |   safe: " + s);
            }
        }
    }
}
