import java.nio.file.*;
import java.util.List;

/** Runs the damaged-data tests of Task B2 on input/damaged_passes.txt. */
public class DamagedDemo {
    public static void main(String[] args) throws Exception {
        List<String> lines = Files.readAllLines(Paths.get("../input/damaged_passes.txt"));
        for (int i = 0; i < lines.size(); i++) {
            String why = PassRecord.check(lines.get(i));
            System.out.println("Line " + (i + 1) + ": " + (why == null ? "OK" : "DAMAGED - " + why));
        }
        PassStore s = new PassStore("../input/damaged_passes.txt");
        System.out.println("find(P2001) = " + s.find("P2001"));
        System.out.println("find(P2002) = " + s.find("P2002") + "  damaged skipped: " + s.lastDamagedCount());
        System.out.println("route 5 passes = " + s.listByRoute(5).size());
    }
}
