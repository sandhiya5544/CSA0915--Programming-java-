import java.sql.*;

/** Opens a connection to the local test database (credentials from env). */
public class Db {
    public static Connection open() throws SQLException {
        String url = System.getenv().getOrDefault("DB_URL",
            "jdbc:mysql://localhost:3306/transport_test");
        String user = System.getenv().getOrDefault("DB_USER", "root");
        String pass = System.getenv().getOrDefault("DB_PASS", "");
        return DriverManager.getConnection(url, user, pass);
    }
}
