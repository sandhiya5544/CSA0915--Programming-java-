# Task 02 – B2 Adversarial Input – paste your output screenshots in this folder

Save each screenshot as a PNG with the file name shown. Each screenshot must show the
command, the input and the COMPLETE output (a screenshot of only a final message is not enough).

- 01_users_table.png            (SELECT * FROM users in the MySQL client)
- 02_login_unsafe_vs_safe.png   (LoginDemo: SQL sent and verdicts for all 6 cases)
- 03_damaged_data_tests.png     (DamagedDemo output for the damaged file)

Also save raw timing values (CSV) here and link them from the main README.md.
